<?php 
date_default_timezone_set('UTC');
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$username=$_POST['fullname'];
$email=$_POST['email'];
$pass=$_POST['password'];
$repass=$_POST['retype-password'];

//database connection --------suru
$conn = new mysqli('localhost:3306','root','','sm');
if ($conn->connect_error) {
    die("DEAD Connection :(");
}
$sql="insert into `registration`values(0,'$username','$email','$pass')";
$r=$conn->query($sql);
$sql1 = "select id from  `registration` where username='$username'";
    $r1 = $conn->query($sql1);
    $row1 = $r1->fetch_assoc();
    // $x = intval($row1['id']);
    // $sql = "insert into  `account` values(0,'$x','$username','$email','$pass')";
    $r = $conn->query($sql);
    echo"user registered";
    header("location:sign.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="sign.css">
    <title>StarGaze Register</title>
</head>
<!-- <script>
     function retypass() {
        var password = document.getElementById("password").value;
        var retypePassword = document.getElementById("retype-password").value;
            console.log(password);
            console.log(retype-password);
        if (password !== retypePassword) {
            alert("DONOT MATCH RETRY");
            

            return false; 
        }
        return true; 
    }
    </script> -->

<body>
    <div class="card">
        <a href="/main.html">
        <div class="logo">
            <i class='bx bxs-star'></i>
        </div></a>
        <h2>Register a new membership</h2>
        <form class="form" action="register.php" method="post" >
            <input type="text" placeholder="FullName" name="fullname">
            <input type="email" placeholder="Email" name="email">
            <input type="password" placeholder="Password" name="password">
            <input type="password" placeholder="Retype-Password" name="retype-password">
            <button type="submit" onclick="retypass()">SIGN UP</button>
        </form>
        <footer>
            Existing users, sign in
            <a href="sign.php">Here</a>
        </footer>
    </div>
</body>
</html>
