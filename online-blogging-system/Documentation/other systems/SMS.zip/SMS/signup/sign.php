<?php
if(isset($_POST['login'])){
    $email=$_POST['email'];
    $password=$_POST['password'];
    $conn=new mysqli("localhost:3306","root","","sm");
    if($conn->error){
        echo("No connection :(");
    }
    $sql="select * from registration where email='$email' and password='$password' ";
    $r=$conn->query($sql);
    if($r){
    $row=$r->fetch_assoc();
    session_start();
    $_SESSION['id']=$row['id'];
    $_SESSION['username']=$row['username'];
    header("Location:../main.php");
    }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="sign.css">
    <title>StarGaze Login</title>
</head>
<body>
    <div class="card">
        <a href="/">
        <div class="logo">
            <i class='bx bxs-star'></i>
        </div></a>
        <h2>Sign in to start your session</h2>
        <form class="form" action="<?php echo $_SERVER['PHP_SELF']?>" method="POST">
            
            <input type="email" placeholder="Email" name="email">
            <input type="password" placeholder="Password" name="password">
            <button type="submit" name="login">Login</button>
        </form>
        <footer>
            Register a new membership
            <a href="register.php">Here</a>
        </footer>
    </div>
</body>
</html>