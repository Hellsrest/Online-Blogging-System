<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="main.css">
    <title>Scholarship Management System</title>

</head>
<body>
    
    <div class="main">
        <!--Nav-->
        <div class="navbar">
            <a href="#" class="logo">Starz Gaze</a>
            <div class="nav-links">
                <span class="item selected">Home</span>
                <span id="" class="item">Get started</span>
            </div>
            <div class="nav-buttons" id="navMenu">
                <a href="signup/sign.php">
                <button class="nav-btn selected" > login</button></a>
            </div>
            <button class="toggler">
                <i class='bx bx-menu'></i>
            </button>
        </div>
        <!-- End of Nav -->


        <!-- Top  -->
        <div class="top-container">
            <div class="info-box">
                <p class="header">
                    One of the Largest scholarship providing Academy in Nepal   </p>
                    <p class="info-text">
                        Explore the best collections from hand-picked Colleges out there and find your gem here in Starz Gaze
                    </p>
                    <div class="info-buttons">
                       <a href="dash\dash.html">  <button class="info-btn selected">Apply</button></a>
                    </div>
            </div>
            <div class="apply">
                <img src="/images/pro1.jpg" class="apply-pic">
                <div class="apply-content">
                    <div class="info">
                        <img src="images/pro2.jpg" class="info-img">
                        <div>
                            <p>Aashu</p>
                            <p>0.27 eth</p>
                        </div>
                        <div class="likes">
                            <div class="icon-box">
                                <i class='bx bx-heart'></i>
                             25800
                            </div>
                        </div>
                    </div>
                </div>            
            </div>
        </div>
        <!-- End Top -->

        <!-- Get Started -->
        <div class="get-started">
            <p class="header">Getting started</p>
            <p class="info-text">Apply for the SCHOLARSHIPS from the Nation's top colleges</p>
            <div class="item-box">
                <div class="item-container">
                    <div class="item">
                        <i class='bx bx-check-shield'></i>
                    </div>
                    <p>All transactions are safe </p>
                </div>

                <div class="item-container">
                    <div class="item">
                        <i class='bx bx-wallet'></i>
                    </div>
                    <p>connect your wallet</p>
                </div>
                <div class="item-container">
                    <div class="item">
                        <i class='bx bx-money'></i>
                    </div>
                    <p>Always free for any change </p>
                </div>
                <div class="item-container">
                    <div class="item">
                        <i class='bx bxs-rocket'></i>
                    </div>
                    <p>BUild your future </p>
                </div>
            </div>
        </div>

        <!-- END of Get started -->

        <!-- Footer -->

        <div class="footer">
            <div class="footer-header">
                If you want to study something truly and wholeheartedly then you are at the right place Starz Gaze.
            </div>
            <div class="footer-links">
                <div class="link">
                    <h5>Apply</h5>
                    <p>Home</p>
                    <p>Getstarted</p>
                    <p>Discover</p>
                    <p>Learn more</p>
                </div>
                <div class="link">
                    <h5>company</h5>
                    <p>About us</p>
                    <p>Services</p>
                    <p>Team info</p>
                </div>
                <div class="link">
                    <h5>Contact</h5>
                    <p>Github</p>
                    <p>Instagram</p>
                    <p>Twitter</p>
                    <p>Facebook</p>
                </div>
            </div>
        </div>
        <!-- End of Footer -->
        <div class="copyright">
            <p>Copyright 2024, Aashutosh khadka, RR Campus. </p>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>